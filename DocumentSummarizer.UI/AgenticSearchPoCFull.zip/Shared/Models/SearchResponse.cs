public class SearchResponse
{
    public string Summary { get; set; }
}