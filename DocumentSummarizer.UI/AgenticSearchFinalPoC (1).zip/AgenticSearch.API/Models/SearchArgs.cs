public class SearchArgs
{
    public string query { get; set; }
}