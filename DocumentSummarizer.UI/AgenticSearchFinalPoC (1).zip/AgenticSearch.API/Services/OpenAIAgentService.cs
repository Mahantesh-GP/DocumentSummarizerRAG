public class OpenAIAgentService
{
    private readonly AzureSearchService _searchService;
    private readonly OpenAIClient _openAI;

    public OpenAIAgentService(AzureSearchService searchService, IConfiguration config)
    {
        _searchService = searchService;
        _openAI = new OpenAIClient(new Uri(config["OpenAI:Endpoint"]), new AzureKeyCredential(config["OpenAI:Key"]));
    }

    public async Task<string> HandleQueryAsync(string userQuery)
    {
        var chat = new List<ChatMessage>
        {
            new ChatMessage(ChatRole.System, "You are an intelligent agent that uses document search to answer queries."),
            new ChatMessage(ChatRole.User, userQuery)
        };

        var functions = new List<FunctionDefinition>
        {
            new FunctionDefinition
            {
                Name = "search_documents",
                Description = "Search documents from Azure Cognitive Search",
                Parameters = BinaryData.FromObjectAsJson(new
                {
                    type = "object",
                    properties = new {
                        query = new { type = "string", description = "Query to search for" }
                    },
                    required = new[] { "query" }
                })
            }
        };

        var options = new ChatCompletionsOptions
        {
            DeploymentName = "gpt-4-mini",
            Messages = chat,
            Functions = functions,
            FunctionCall = FunctionCall.Auto
        };

        var response = await _openAI.GetChatCompletionsAsync(options);
        var message = response.Value.Choices[0].Message;

        if (message.FunctionCall?.Name == "search_documents")
        {
            var args = JsonSerializer.Deserialize<SearchArgs>(message.FunctionCall.Arguments.ToString());
            var docs = await _searchService.HybridSearchAsync(args.query);
            var json = JsonSerializer.Serialize(docs);

            chat.Add(new ChatMessage(ChatRole.Function, json) { Name = "search_documents" });

            var final = await _openAI.GetChatCompletionsAsync(new ChatCompletionsOptions
            {
                DeploymentName = "gpt-4-mini",
                Messages = chat
            });

            return final.Value.Choices[0].Message.Content;
        }

        return message.Content ?? "No result.";
    }
}