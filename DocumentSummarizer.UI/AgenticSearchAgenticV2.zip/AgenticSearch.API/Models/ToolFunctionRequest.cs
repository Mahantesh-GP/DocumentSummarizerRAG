public class ToolFunctionRequest
{
    public string Query { get; set; }
}