﻿namespace AgenticRAG;

public class Request
{
    public string prompt { get; set; }
}

