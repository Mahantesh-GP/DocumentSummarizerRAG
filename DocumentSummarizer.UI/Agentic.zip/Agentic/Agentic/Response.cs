﻿namespace AgenticRAG;

public class Response
{
    public DateOnly Date { get; set; }

    public string AgentName { get; set; }

    public string? Content { get; set; }
}

