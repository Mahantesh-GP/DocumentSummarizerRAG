// Core function that searches the index
public class NameSearchFunction { }