// Entry point for ASP.NET Core
public class Program { public static void Main() {} }