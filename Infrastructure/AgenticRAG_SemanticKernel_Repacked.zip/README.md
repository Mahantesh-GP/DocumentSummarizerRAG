# Agentic RAG Semantic Kernel

This is a reference architecture for Name Search using Agentic RAG in Semantic Kernel.