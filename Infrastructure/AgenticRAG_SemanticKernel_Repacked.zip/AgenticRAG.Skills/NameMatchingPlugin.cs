// Skill to match similar sounding names
public class NameMatchingPlugin { }