namespace AzureFunction_FieldExtractor.Utils;

public static class TokenUtils
{
    public static List<string> ChunkText(string text, int maxTokensPerChunk = 1000)
    {
        var words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var chunks = new List<string>();
        var current = new List<string>();
        var count = 0;

        foreach (var word in words)
        {
            current.Add(word);
            count++;
            if (count >= maxTokensPerChunk)
            {
                chunks.Add(string.Join(" ", current));
                current.Clear();
                count = 0;
            }
        }

        if (current.Count > 0)
            chunks.Add(string.Join(" ", current));

        return chunks;
    }
}