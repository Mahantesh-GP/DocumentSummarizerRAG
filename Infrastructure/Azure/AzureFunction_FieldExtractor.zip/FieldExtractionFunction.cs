using System.Net;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using AzureFunction_FieldExtractor.Models;
using AzureFunction_FieldExtractor.Services;
using AzureFunction_FieldExtractor.Utils;

namespace AzureFunction_FieldExtractor;

public class FieldExtractionFunction
{
    [Function("FieldExtractionFunction")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req,
        FunctionContext executionContext)
    {
        var logger = executionContext.GetLogger("FieldExtractionFunction");

        var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        var input = JsonSerializer.Deserialize<Dictionary<string, string>>(requestBody);
        
        if (!input.TryGetValue("merged_content", out var content) || string.IsNullOrWhiteSpace(content))
        {
            logger.LogWarning("Missing or empty merged_content.");
            var badResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badResponse.WriteStringAsync("Missing merged_content.");
            return badResponse;
        }

        var service = new OpenAiService();
        var chunks = TokenUtils.ChunkText(content, maxTokensPerChunk: 1000);
        var combinedResults = new FieldExtractionResult();

        foreach (var chunk in chunks)
        {
            var result = await service.ExtractFieldsFromChunkAsync(chunk);
            combinedResults.Merge(result);
        }

        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteAsJsonAsync(combinedResults);
        return response;
    }
}