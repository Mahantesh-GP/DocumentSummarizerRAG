namespace AzureFunction_FieldExtractor.Models;

public class FieldExtractionResult
{
    public string PolicyNumber { get; set; }
    public string ClosingDate { get; set; }
    public string BorrowerName { get; set; }
    public string SellerName { get; set; }
    public string PropertyAddress { get; set; }

    public void Merge(FieldExtractionResult other)
    {
        PolicyNumber ??= other.PolicyNumber;
        ClosingDate ??= other.ClosingDate;
        BorrowerName ??= other.BorrowerName;
        SellerName ??= other.SellerName;
        PropertyAddress ??= other.PropertyAddress;
    }
}